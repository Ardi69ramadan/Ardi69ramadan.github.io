# Will you be my Valentine?
If you like a boy, asking him to be your valentine is a great way to let him know how you feel. There are lots of creative and fun ways to ask him, and this is one of those ways! No matter who or when you ask, I don't think they'll be able to say no ;)
### Happy Valentine's Day
![image](https://user-images.githubusercontent.com/104410750/214224557-1a793508-735f-4d6e-8258-ec03799e2338.png)

(note : artwork is my own)
